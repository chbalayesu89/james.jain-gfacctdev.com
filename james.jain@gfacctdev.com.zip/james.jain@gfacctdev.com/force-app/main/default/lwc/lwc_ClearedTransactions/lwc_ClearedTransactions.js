import {api, LightningElement, track, wire } from 'lwc';
import getObjFields from "@salesforce/apex/ClearedTransactions.getObjFields"; // Call "getObjFields" method situated in the backend class "NetsuiteSFTriggerMapping"
import getSelectedObjectRecords from '@salesforce/apex/ClearedTransactions.getSelectedObjectRecords';
import updateRecords from '@salesforce/apex/ClearedTransactions.saveRecords';
import getPicklistOptions from '@salesforce/apex/ClearedTransactions.getPicklistOptions';
import getRelatedObjectRecords from '@salesforce/apex/ClearedTransactions.getRelatedObjectRecords';

const PAGESIZEOPTIONS = [10,20,40];

export default class Lwc_ClearedTransactions extends LightningElement {
    @api recordId;
    @track isLoading = true;
    @track SFObjApiName ="GFERP__GL_Entry__c";

    //This array can be anything as per values
    @api values = [];
    error;
    columns=[];// = this.values;
    opps; //All opportunities available for data table    
    showTable = false; //Used to render table after we get the data from apex controller    
    pageSizeOptions = PAGESIZEOPTIONS;
    isLoading = true;
    loadMessage = "Loading...";

    @track selectedvalues = [];
    @api picklistlabel = "Status";
    @api checkServer = false;

    showdropdown;
    tempColumns=[];// = this.values;

    connectedCallback() {
        console.log('@@recordId ::',this.recordId);
        
    }

    renderedCallback(){
        console.log('@@recordId 1::',this.recordId);
        if(!this.checkServer){
            this.handleNSObjectSelection();
            this.checkServer = true
        }
    }

    handleNSObjectSelection(){        
        this.isLoading = true; // Turn on spinner
        this.values = [];
        this.columns =  [
            { label: 'Customer/Payee', fieldName: 'GFERP__Account__r.Name' },
            { label: 'Date', fieldName: 'GFERP__Document_Date__c', type: 'date' },
            { label: 'Amount', fieldName: 'GFERP__Amount__c', type: 'currency' },
            { label: 'Reference', fieldName: 'GFERP__Amount__c', type: 'currency' },
            { label: 'Source', fieldName: 'GFERP__Amount__c', type: 'currency' },
        ];
        this.allField = "Cleared__c, Bank_Reconciliation__c, GFERP__Account__r.Name, GFERP__Document_Date__c, GFERP__Amount__c";

        this.getOpportunities_();
/*
        getObjFields({
            singleSFObjName: this.SFObjApiName,
        })
        .then((data) => {
            if (data) {
                if (data.message != undefined) {
                this.messsage = data.message.message;
                } else {
                    this.allField = "Cleared__c, Bank_Reconciliation__c, GFERP__Account__r.Name, GFERP__Document_Date__c, GFERP__Amount__c, CreatedDate, CreatedBy.Name, LastModifiedBy.Name";

                    let sfMap = data.SalesforceObject; // get selected Salesforce object field Info.
                    
                    for (let sfKey in sfMap) {
                        if (sfKey !== "Id" && sfKey !== "Name" && sfKey !== "CreatedDate" && sfKey !== "CreatedById" && sfKey !== "BillingAddress" && sfKey !== "ShippingAddress" && sfMap.hasOwnProperty(sfKey)) {
                            //Add field label and API.
                            var obj = {};
                            obj.label = sfMap[sfKey].split(":")[0]; //get selected Salesforce object field label
                            obj.value = sfMap[sfKey].split(":")[0];
                            obj.fieldName = sfKey;  // Field API 
                            obj.type = sfMap[sfKey].split(":")[1];
                            if(obj.type == "URL"){
                                obj.type = "link"; 
                                obj.linkLabel = sfKey; 
                                obj.sortBy = sfKey;
                                obj.title = "Click to view";
                                obj.target = "_blank";
                            }
                            if(sfKey === "LastModifiedById"){
                                obj.fieldName = "LastModifiedByName";  // Field API 
                                obj.type = "text";  
                            }
                            if(sfKey === "OwnerId"){
                                obj.fieldName = "OwnerName";  // Field API 
                                obj.type = "text"; 
                                this.allField = this.allField + " ,Owner.Name";
                            }
                            if(obj.type == 'LOOKUP' || obj.type == "REFERENCE" || obj.type == "Hierarchy"){
                                obj.iconName = 'standard:account';
                            }

                            obj.sortable = true;
                            obj.resizable = true;
                            obj.editable = false;//sfMap[sfKey].split(":")[2];
                            obj.selected = false; //get selected Salesforce object field API name

                            if(sfKey === "GFERP__Document_Date__c"){
                                obj.label = "Date";
                                obj.fieldName = "Date";  // Field API 
                                obj.type = "date"; 
                                this.columns.push(obj);
                            }else if(sfKey === "GFERP__Amount__c"){
                                obj.label = "Amount";
                                obj.fieldName = "Amount";  // Field API 
                                obj.type = "date"; 
                                this.columns.push(obj);
                            }

                            this.values.push(obj);
                        }else if(sfKey == "Name"){
                            var objTemp = {};
                            objTemp.label = sfMap[sfKey].split(":")[0]; //get selected Salesforce object field label
                            objTemp.value = sfMap[sfKey].split(":")[0];
                            objTemp.fieldName = 'Id';  // Field API 
                            objTemp.type = "link"; 
                            objTemp.linkLabel = sfKey; 
                            objTemp.sortBy = sfKey;
                            objTemp.title = "Click to view";
                            objTemp.target = "_blank";
                            objTemp.sortable = true;
                            objTemp.resizable = true;
                            objTemp.editable = false;
                            objTemp.iconName = 'standard:account';
                            objTemp.selected = true; //get selected Salesforce object field API name
                            this.columns.push(objTemp);

                            this.allField = this.allField + " ,Name";
                        }
                    }
                }

                for(let col in this.columns){
                    this.tempColumns.push(this.columns[col]);
                }
                //Sort salesforce object related list by Label from A-Z
                this.values.sort(function (x, y) {
                    if (x.value < y.value) {
                        return -1;
                    }
                    if (x.value > y.value) {
                        return 1;
                    }
                    return 0;
                });

                this.isLoading = false; // Turn off spinner
                if(this.SFObjApiName !== '' && this.SFObjApiName !== null){
                    this.getOpportunities_();
                    this.getPickListValues();
                }
            }
        })
        .catch((error) => {
            this.isLoading = false; // Turn off spinner
            console.log("Error::", error);
        });*/
    }

    getPickListValues(){
        for(let i=0; i<this.values.length; i++){
            if(this.values[i].type == 'PICKLIST'){
                getPicklistOptions({
                    objectApiName: this.SFObjApiName,
                    fieldApiName: this.values[i].fieldName
                })
                .then((data) => {
                    let pickOprions = [];
                    for(let i=0; i<data.length; i++){
                        let objTemp = {value: data[i].value, label: data[i].label};
                        pickOprions.push(objTemp);
                    }
                    this.values[i].options = pickOprions;
                }); 
            }
            if(this.values[i].type == "LOOKUP" || this.values[i].type == "REFERENCE" || this.values[i].type == "Hierarchy"){
                getRelatedObjectRecords({
                    objectApiName: this.SFObjApiName,
                    fieldApiName: this.values[i].fieldName
                })
                .then((data) => {
                    if (data) {
                        let objRelatedRecords = [];
                        for(let j=0; j<data.length; j++){
                            let objTemp = {value: data[j].Id, label: data[j].Name};
                            objRelatedRecords.push(objTemp);
                        }
                        this.values[i].iconName = 'standard:account';
                        this.values[i].options = objRelatedRecords;
                    }
                });
            }
        }
    }


    getOpportunities_(){
        this.showTable = false;
        this.loadMessage = 'Loading...';
        this.isLoading = true;
        this.error = '';

        if(this.SFObjApiName != '' &&  this.allField != ''){
            getSelectedObjectRecords({
            sObjectType : this.SFObjApiName,
            allField : this.allField
            })
            .then(data=>{
                this.opps = [];
                console.log('@@data ::',data);
                for(let i=0; i<data.length; i++){
                    let obj = {...data[i]};
                    if(obj.Date){
                        obj.Date = data[i].GFERP__Document_Date__c;
                    }
                    this.opps.push(obj);
                }
                this.showTable = true;
                this.isLoading = false;
            })
            .catch(error=>{
                this.error = JSON.stringify(error);
                this.showTable = true;
                this.isLoading = false;
            }); 
        }else{
            this.error = 'Please Select Salesforce Object';
            this.isLoading = false;
        }
              
    }

    handleRowSelection(event){
        console.log('Records selected***'+JSON.stringify(event.detail));
    }

    saveRecords(event){
        this.loadMessage = 'Saving...';
        this.isLoading = true;
        this.error = '';
        console.log('@@JSON.stringify(event.detail) ::',JSON.stringify(event.detail));
        updateRecords({
            recsString: JSON.stringify(event.detail),
            objName: this.SFObjApiName
        })
        .then(response=>{
            if(response==='success') this.getOpportunities_();
        })
        .catch(error=>{
            console.log('recs save error***'+error);
            this.error = JSON.stringify(error);
            this.isLoading = false;
        });
    }

}