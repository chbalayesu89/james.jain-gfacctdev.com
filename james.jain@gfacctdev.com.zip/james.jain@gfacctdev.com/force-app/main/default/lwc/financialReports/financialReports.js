import {LightningElement, track} from 'lwc';
import {NavigationMixin} from 'lightning/navigation';
import getFinancialReportingList from '@salesforce/apex/RunFinancialReports.getFinancialReportingList';
import getGlSummary from '@salesforce/apex/FinancialReportResultController.getGlSummary';
import deleteMultipleFinancialReportingRecord
    from "@salesforce/apex/RunFinancialReports.deleteMultipleFinancialReportingRecord";
import getFinancialReportResultRecord
    from "@salesforce/apexContinuation/FinancialReportResultController.getFinancialReportResultRecord";
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

const columns = [
    {
        label: 'Report Number',
        fieldName: 'reportName',
        type: 'url',
        typeAttributes: {label: {fieldName: 'name'}, target: '_blank'}
    },
    {
        label: 'Ledger',
        fieldName: 'legderId',
        type: 'url',
        typeAttributes: {label: {fieldName: 'ledger'}, target: '_blank'}
    },
    {
        label: 'Start Period',
        fieldName: 'startPeriod',
        type: 'url',
        typeAttributes: {label: {fieldName: 'sp'}, target: '_blank'}
    },
    {
        label: 'End Period',
        fieldName: 'endPeriod',
        type: 'url',
        typeAttributes: {label: {fieldName: 'ep'}, target: '_blank'}
    },
    {label: 'GL Variable 1', fieldName: 'glVar1'},
    {label: 'GL Variable 2', fieldName: 'glVar2'},
    {label: 'GL Variable 3', fieldName: 'glVar3'},
    {label: 'GL Variable 4', fieldName: 'glVar1'},
    {label: 'Status', fieldName: 'status'},
    {label: 'Completed Date/Time', fieldName: 'completedDateTime'},
    {label: 'Created By', fieldName: 'createdBy', type: 'date'},
];

export default class FinancialReports extends NavigationMixin(LightningElement) {
    get options() {
        return [
            {label: 'No Rounding', value: 'No Rounding'},
            {label: 'Whole Amounts', value: 'Whole Amounts'},
            {label: 'Round to 1000s', value: 'Round to 1000s'},
        ];
    }

    get currencyOptions() {
        return [
            {label: 'USD', value: 'USD'},
            {label: 'EUR', value: 'EUR'},
            {label: 'GBP', value: 'GBP'},
        ];
    }

    StandardReportRows = [];
    columns = columns;
    refreshTable
    showTabs = false;
    isLoading = false;
    insertedRecordId = null;
    showSpinner = false;
    isShowToast = false;
    isGlAccShow = true;
    roundingTextValue = '';
    currencyValue = 'USD';
    @track value;
    @track includeSubType1CheckBoxValue = false;
    @track includeSubType2CheckBoxValue = false;
    @track suppressZeroAmountRowsCheckBoxValue = false;
    @track startAccountingPeriodId;
    @track endAccountingPeriodId;
    @track endDate;
    @track allCheck = false;
    @track isModalOpen = false;
    @track cardTitle = '';
    @track items = [
        {
            id: 'menu-item-1',
            label: 'Profit & Loss',
            value: 'Profit & Loss',
        },
        {
            id: 'menu-item-2',
            label: 'P & L vs. Budget',
            value: 'P & L vs. Budget',
        },
        {
            id: 'menu-item-3',
            label: 'Balance Sheet',
            value: 'Balance Sheet',
        },
        {
            id: 'menu-item-4',
            label: 'Trial Balance',
            value: 'Trial Balance',
        },
        {
            id: 'menu-item-5',
            label: 'Cash Flow',
            value: 'Cash Flow',
        },
        {
            id: 'menu-item-6',
            label: 'Ledger Inquiry',
            value: 'Ledger Inquiry',
        },
    ];

    glRecord;
    @track glAccountId;
    @track glKeyValue;
    @track glKeyValueCounter = 1;

    connectedCallback() {
        this.isLoading = true;
        getGlSummary({}).then((res) => {
            this.glRecord = res;
            this.startAccountingPeriodId = res.GFERP__Accounting_Period__c;
            this.endAccountingPeriodId = res.GFERP__Accounting_Period__c;
            this.glAccountId = res.GFERP__GL_Account__c;
            this.glKeyValue =  Date.now().toString();
            console.log('this.glRecord', this.glRecord);
        });
        getFinancialReportingList({}).then((res) => {
            this.showTabs = true;
            this.isLoading = false;
            console.log('res: ', res);
            if (res != null) {
                this.StandardReportRows = res;
                this.StandardReportRows = [...this.StandardReportRows];
                this.refreshTable = this.StandardReportRows;
            }
            console.log('this.StandardReportRows: ', this.StandardReportRows);
            // this.generateRows();
        });
    }

    generateRows() {
        this.StandardReportRows && this.StandardReportRows.forEach((element) => {
            if (element.glSummaryId == this.insertedRecordId) {
                element.isImage = true;
            } else {
                element.isImage = false;
            }
        });
        this.StandardReportRows = [...this.StandardReportRows];
        console.log('this.StandardReportRows: ', this.StandardReportRows);
    }

    runReport(event) {
        try {
            var tempObj = {};
            this.showSpinner = false;
            this.glKeyValueCounter++;
            this.glKeyValue =  Date.now().toString();
            this.insertedRecordId = event.detail.id;
            tempObj.glInsertedRecordId = this.insertedRecordId;
            tempObj.currencyValue = this.currencyValue;
            tempObj.includeSubType1CheckBoxValue = Boolean(this.includeSubType1CheckBoxValue);
            tempObj.includeSubType2CheckBoxValue = this.includeSubType2CheckBoxValue;
            tempObj.suppressZeroAmountRowsCheckBoxValue = this.suppressZeroAmountRowsCheckBoxValue;
            tempObj.roundingTextValue = this.roundingTextValue;
            tempObj.reportRounding = this.value;
            tempObj.startAccountingPeriodId = this.startAccountingPeriodId;
            tempObj.endAccountingPeriodId = this.endAccountingPeriodId;

            console.log('tempObj: ', tempObj);
            getFinancialReportResultRecord({newItems: tempObj}).then(() => {
                getFinancialReportingList({}).then((res) => {
                    if (res != null) {
                        console.log('res: ', res);
                        this.StandardReportRows = res;
                        this.StandardReportRows = [...this.StandardReportRows];
                        this.generateRows();
                        const toast = new ShowToastEvent({
                            title: 'Financial Reports',
                            message: 'Report generation is completed.',
                            variant: 'success',
                            mode: 'sticky'
                        });
                    }
                }).catch(error => {
                })
            }).catch(error => {
            })
            setTimeout(() => {
                this.isShowToast = false;
                this.showTabs = false;
                this.insertedRecordId = null;
                this.generateRows();
                this.showTabs = true;
                this.toastTitle = 'Financial Reports';
                this.toastMessage = 'Report generation is completed.';
                this.toastVariant = 'success';
                this.isShowToast = true;
                setTimeout(() => {
                    this.isShowToast = false;
                }, 1000);
            }, 6000);
        } catch (error) {
            this.showSpinner = false;
            console.log('Error: ', error);
        }
    }

    handleSubmitError(event) {
        this.showSpinner = false;
        console.log(JSON.parse(JSON.stringify(event.detail)))
    }

    handleOnSubmit(event) {
        this.showSpinner = true;
        this.toastTitle = 'Financial Reports';
        this.toastMessage = 'Report generation is in progress.';
        this.toastVariant = 'success';
        this.isShowToast = true;
        event.preventDefault();       // stop the form from submitting
        const fields = event.detail.fields;
        console.log('fields: ', JSON.parse(JSON.stringify(fields)));
        // fields.Report_Subtitle__c = 'Subtitle here';
        this.template.querySelector('lightning-record-edit-form').submit(fields);
    }

    openIdLink(event) {
        var recordId = event.target.dataset.legerid;
        window.open('/' + recordId, "_blank");
    }

    allSelected(event) {
        const selectedRows = this.template.querySelectorAll('lightning-input');
        for (let i = 0; i < selectedRows.length; i++) {
            if (selectedRows[i].type === 'checkbox') {
                selectedRows[i].checked = event.target.checked;
            }
        }
    }

    submitDetails() {
        this.isModalOpen = false;
        this.showSpinner = true;
        let selectedCons = [];
        let selectedRows = this.template.querySelectorAll('lightning-input');
        for (let i = 0; i < selectedRows.length; i++) {
            if (selectedRows[i].checked && selectedRows[i].type === 'checkbox') {
                selectedCons.push(selectedRows[i].dataset.id);
                this.StandardReportRows.splice(selectedRows[i].dataset.id, 1)
                this.index--;
            }
        }
        if (selectedCons && selectedCons.length > 0) {
            deleteMultipleFinancialReportingRecord({frrObj: selectedCons}).then(() => {
                this.showSpinner = false;
                const evt = new ShowToastEvent({
                    title: 'Success Message',
                    message: 'Record deleted successfully',
                    variant: 'success',
                    mode: 'dismissible'
                });
                this.dispatchEvent(evt);
            });
        }
    }

    deleteSelectedRecords() {
        this.isModalOpen = true;
    }

    closeModal() {
        this.isModalOpen = false;
    }

    handleColumnClick(event) {
        let recordId = event.target.dataset.id;
        let frrId = event.target.dataset.frrId;
        console.log('frrId2: ', frrId);

        var compDefinition = {
            componentDef: "c:asReportDetail",
            attributes: {
                recordId: recordId,
                frrId: frrId
            }
        };
        var encodedCompDef = btoa(JSON.stringify(compDefinition));
        window.open('/one/one.app#' + encodedCompDef, "_blank");
    }

    handleMenuSelect(event) {
        let seletedItem = event.detail.value;
        this.cardTitle = seletedItem;
    }

    closeToast() {
        this.isShowToast = false;
    }

    handleIncludeSubType1Change(event) {
        this.includeSubType1CheckBoxValue = event.target.checked;
        console.log('includeSubType1CheckBoxValue: ', this.includeSubType1CheckBoxValue);
    }

    handleIncludeSubType2Change(event) {
        this.includeSubType2CheckBoxValue = event.target.checked;
        console.log('includeSubType2CheckBoxValue: ', this.includeSubType2CheckBoxValue);
    }

    handleSuppressZeroAmountRowsChange(event) {
        this.suppressZeroAmountRowsCheckBoxValue = event.target.checked;
        console.log('suppressZeroAmountRowsCheckBoxValue: ', this.suppressZeroAmountRowsCheckBoxValue);
    }

    handleRoundingChange(event) {
        this.roundingTextValue = event.target.value;
        console.log('roundingTextValue: ', this.roundingTextValue);
    }

    handleChange(event) {
        this.value = event.target.value;
        console.log('Value: ', this.value);
    }

    handleCurrencyChange(event) {
        this.currencyValue = event.target.value;
        console.log('currencyValue: ', this.currencyValue);
    }

    handleStartAccountingPeriod(event) {
        this.startAccountingPeriodId = event.target.value;
        console.log('this.startAccountingPeriodId: ', this.startAccountingPeriodId);
    }

    handleEndAccountingPeriod(event) {
        this.startAccountingPeriodId = event.target.value;
        console.log('this.startAccountingPeriodId: ', this.startAccountingPeriodId);
    }

    handleOnChange(event) {
        if (this.isGlAccShow) {
            this.isGlAccShow = false;
        } else {
            this.isGlAccShow = true;
        }
    }
}