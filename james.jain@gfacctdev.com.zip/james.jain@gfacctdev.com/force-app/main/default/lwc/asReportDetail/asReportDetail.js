import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class AsReportDetail extends LightningElement {
    activeSections = [];
    @api recordId;
    @api frrId;
    isEdit = false;

    connectedCallback() {
        console.log("FRR Id = ", this.recordId);
        // console.log("GL Account Id = ", this.frrId);
    }

    editToggel(event) {
        this.isEdit = !this.isEdit;
    }

    editToggelWithToast(event) {
        const ev = new ShowToastEvent({
            title: 'Subtitle Updated',
            variant: 'success'
        });
        this.dispatchEvent(ev);
        this.editToggel(null);
    }
}