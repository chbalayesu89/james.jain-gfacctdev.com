const convertMapToJson = (mapJson) => {
    const tempJson = [];
    for (var key in mapJson) {
        tempJson.push({ label: key, values: mapJson[key] });
    }
    return tempJson;
}
export {convertMapToJson};