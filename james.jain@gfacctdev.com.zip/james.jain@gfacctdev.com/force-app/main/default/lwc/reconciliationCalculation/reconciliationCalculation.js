import { LightningElement, api } from 'lwc';
export default class ReconciliationCalculation extends LightningElement {
    @api objectApiName;
    @api recordId;

}