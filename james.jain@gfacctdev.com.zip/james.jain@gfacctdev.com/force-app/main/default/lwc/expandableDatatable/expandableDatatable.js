import {api, LightningElement} from 'lwc';
import {convertMapToJson} from 'c/util';

import getFinancialStatementResultValue
    from '@salesforce/apex/FinancialReportResultController.getFinancialStatementResultValue';


export default class ExpandableDatatable extends LightningElement {

    @api recordId;
    @api frrId;
    colWrapperSet;
    revWrapperRes = [];
    expWrapperRes = [];
    netIncomeWrapperRes = [];
    revWrapperMap;
    revWrapperMapList = [];
    expWrapperMap;
    isOpenRevenue = false;
    tableArray = [
        {
            label: 'Revenue', Value: '', havingSubValues: true, isExpanded: false,
            arr: [
                {
                    label: 'Service Revenue', Value: '', havingSubValues: true, isExpanded: false, arr: [
                        {label: ' 40100-Sales - Sales Charge', Value: '', havingSubValues: false, isTotal: false},
                        {label: 'Total Service Revenue', Value: '', havingSubValues: false, isTotal: true}
                    ]
                }
            ]
        },
        {label: 'Total Revenue', havingSubValues: false, Value: ''},
        {label: '', Value: '', havingSubValues: false},
        {
            label: 'Expense', Value: '', havingSubValues: true, isExpanded: false,
            arr: [
                {
                    label: 'Cost of Goods Sold', havingSubValues: true, Value: '', isExpanded: false, arr: [
                        {label: '50000-Cost of Goods Sold', Value: '', havingSubValues: false, isTotal: false},
                        {label: 'Total Cost of Goods Sold', Value: '', havingSubValues: false, isTotal: true}
                    ]
                },
                {
                    label: 'Uncategorized', Value: '', havingSubValues: true, isExpanded: false, arr: [
                        {label: '20300-Purchase - Sales Charge', Value: '', havingSubValues: false},
                        {label: '40100-Sales', Value: '', havingSubValues: false},
                        {label: 'Total Uncategorized', Value: '', havingSubValues: false, isTotal: true}
                    ]
                }
            ]
        },
        {label: 'Total Expense', havingSubValues: false, Value: ''},
        {label: '', Value: '', havingSubValues: false},
        {label: 'Net Income', havingSubValues: false, Value: ''},
    ];

    finalTableData = [];

    connectedCallback() {
        getFinancialStatementResultValue({fRRId: this.frrId}).then((res) => {
            console.log('res', res);
            this.colWrapperSet = res.colWrapperSet;
            // this.colWrapperSet.shift();
            // this.colWrapperSet.push('Total');
            // this.colWrapperSet = [...this.colWrapperSet];
            this.revWrapperRes.revWrapperMap = res.revWrapperList;
            this.expWrapperRes.expWrapperMap = res.expWrapperList;
            this.expWrapperRes.totalRevWrapperMap = res.totalRevWrapperMap;
            this.expWrapperRes.totalExpWrapperMap = res.totalExpWrapperMap;
            this.revWrapperRes.revWrapperList = convertMapToJson(this.revWrapperRes.revWrapperMap);
            this.expWrapperRes.expWrapperList = convertMapToJson(this.expWrapperRes.expWrapperMap);
            this.expWrapperRes.totalRevWrapperMap = convertMapToJson(this.expWrapperRes.totalRevWrapperMap);
            this.expWrapperRes.totalExpWrapperMap = convertMapToJson(this.expWrapperRes.totalExpWrapperMap);
            this.netIncomeWrapperRes = convertMapToJson(res.totalNetIncomeWrapperMap);


            this.revWrapperRes.revWrapperList.map((ele) => {
                console.log(ele);
                if (ele.values && ele.values.length == undefined) {
                    ele.isExpanded = false;
                    ele.havingSubValues = true;
                    ele.list = convertMapToJson(ele.values);
                    ele.list && ele.list.forEach((ele2) => {
                        console.log(ele2);
                        if (ele2.values && ele2.values.length == undefined) {
                            ele2.isExpanded = false;
                            ele2.havingSubValues = true;
                            ele2.list = convertMapToJson(ele2.values);
                            ele2.list && ele2.list.forEach((ele3) => {
                                if (ele3.values && ele3.values.length == undefined) {
                                    ele3.isExpanded = false;
                                    ele3.havingSubValues = true;
                                    ele3.list = convertMapToJson(ele3.values);
                                    ele3.list && ele3.list.forEach((ele4) => {
                                        if (ele3.values && ele3.values.length != undefined) {
                                            var temp = ele4.values.shift();
                                            ele4.values.push(temp);
                                            var tempArr = [];
                                            this.colWrapperSet.forEach((ele) => {
                                                ele4.values.forEach((ele2) => {
                                                    if (ele == ele2.ColumnHeader1) {
                                                        tempArr.push(ele2);
                                                    }
                                                })
                                            });
                                            ele4.values = tempArr;
                                            ele4.values = [...ele4.values];
                                        }
                                    })
                                } else {
                                    var temp = ele3.values.shift();
                                    ele3.values.push(temp);
                                    var tempArr = [];
                                    this.colWrapperSet.forEach((ele) => {
                                        ele3.values.forEach((ele2) => {
                                            if (ele == ele2.ColumnHeader1) {
                                                tempArr.push(ele2);
                                            }
                                        })
                                    });
                                    ele3.values = tempArr;
                                    ele3.values = [...ele3.values];
                                }
                            });
                        } else {
                            var temp = ele2.values.shift();
                            ele2.values.push(temp);
                            var tempArr = [];
                            this.colWrapperSet.forEach((ele) => {
                                ele2.values.forEach((ele2) => {
                                    if (ele == ele2.ColumnHeader1) {
                                        tempArr.push(ele2);
                                    }
                                })
                            });
                            ele2.values = tempArr;
                            ele2.values = [...ele2.values];
                        }
                    })
                } else {
                    var temp = ele.values.shift();
                    ele.values.push(temp);
                    var tempArr = [];
                    this.colWrapperSet.forEach((ele) => {
                        ele.values.forEach((ele) => {
                            if (ele == ele.ColumnHeader1) {
                                tempArr.push(ele);
                            }
                        })
                    });
                    ele.values = tempArr;
                    ele.values = [...ele.values];
                }
            });
            console.log('this.revWrapperRes.revWrapperList = ', this.revWrapperRes.revWrapperList);

            var tempArr = [];
            this.expWrapperRes.totalRevWrapperMap.forEach((ele2) => {
                this.colWrapperSet && this.colWrapperSet.forEach((ele) => {
                    ele2.values && ele2.values.forEach((ele3) => {
                        if (ele == ele3.ColumnHeader1) {
                            tempArr.push(ele3);
                        }
                    });
                });
                ele2.values = tempArr;
                ele2.values = [...ele2.values];
                ele2.isExpanded = false;
                ele2.havingSubValues = false;
                var expTotal = 0;
                ele2.values && ele2.values.forEach((ele2) => {
                    expTotal = expTotal + ele2.Amount;
                });
                if (expTotal < 0) {
                    ele2.values.push({
                        CurrencyValue: '(' + (expTotal * -1) + ')',
                        styleCss: 'color:red;',
                        ColumnHeader1: 'Expense Total'
                    });
                } else {
                    ele2.values.push({CurrencyValue: expTotal, ColumnHeader1: 'Expense Total'});
                }
            });
            console.log('this.expWrapperRes.totalRevWrapperMap = ', this.expWrapperRes.totalRevWrapperMap);

            this.finalTableData = this.revWrapperRes.revWrapperList.concat(this.expWrapperRes.totalRevWrapperMap);

            this.expWrapperRes.expWrapperList.map((ele) => {
                if (ele.values && ele.values.length == undefined) {
                    ele.isExpanded = false;
                    ele.havingSubValues = true;
                    ele.list = convertMapToJson(ele.values);
                    ele.list && ele.list.forEach((ele2) => {
                        if (ele2.values && ele2.values.length == undefined) {
                            ele2.isExpanded = false;
                            ele2.havingSubValues = true;
                            ele2.list = convertMapToJson(ele2.values);
                            ele2.list && ele2.list.forEach((ele3) => {
                                if (ele3.values && ele3.values.length == undefined) {
                                    ele3.isExpanded = false;
                                    ele3.havingSubValues = true;
                                    ele3.list = convertMapToJson(ele3.values);
                                    ele3.list && ele3.list.forEach((ele4) => {
                                        if (ele3.values && ele3.values.length != undefined) {
                                            var temp = ele4.values.shift();
                                            ele4.values.push(temp);
                                            var tempArr = [];
                                            this.colWrapperSet.forEach((ele) => {
                                                ele4.values.forEach((ele2) => {
                                                    if (ele == ele2.ColumnHeader1) {
                                                        tempArr.push(ele2);
                                                    }
                                                })
                                            });
                                            ele4.values = tempArr;
                                            ele4.values = [...ele4.values];
                                        }
                                    })
                                } else {
                                    var temp = ele3.values.shift();
                                    ele3.values.push(temp);
                                    var tempArr = [];
                                    this.colWrapperSet.forEach((ele) => {
                                        ele3.values.forEach((ele2) => {
                                            if (ele == ele2.ColumnHeader1) {
                                                tempArr.push(ele2);
                                            }
                                        })
                                    });
                                    ele3.values = tempArr;
                                    ele3.values = [...ele3.values];
                                }
                            });
                        } else {
                            var temp = ele2.values.shift();
                            ele2.values.push(temp);
                            var tempArr = [];
                            this.colWrapperSet.forEach((ele) => {
                                ele2.values.forEach((ele2) => {
                                    if (ele == ele2.ColumnHeader1) {
                                        tempArr.push(ele2);
                                    }
                                })
                            });
                            ele2.values = tempArr;
                            ele2.values = [...ele2.values];
                        }
                    })
                } else {
                    var temp = ele.values.shift();
                    ele.values.push(temp);
                    var tempArr = [];
                    this.colWrapperSet.forEach((ele) => {
                        ele.values.forEach((ele) => {
                            if (ele == ele.ColumnHeader1) {
                                tempArr.push(ele);
                            }
                        })
                    });
                    ele.values = tempArr;
                    ele.values = [...ele.values];
                }
            });
            console.log('this.expWrapperRes.expWrapperList = ', this.expWrapperRes.expWrapperList);
            this.finalTableData = this.finalTableData.concat(this.expWrapperRes.expWrapperList);

            this.expWrapperRes.totalExpWrapperMap.forEach((ele) => {
                ele.isExpanded = false;
                ele.havingSubValues = false;
                var expTotal = 0;
                ele.values && ele.values.forEach((ele2) => {
                    expTotal = expTotal + ele2.Amount;
                });
                if (expTotal < 0) {
                    ele.values.push({
                        CurrencyValue: '(' + (expTotal * -1) + ')',
                        styleCss: 'color:red;',
                        ColumnHeader1: 'Expense Total'
                    });
                } else {
                    ele.values.push({CurrencyValue: expTotal, ColumnHeader1: 'Expense Total'});
                }
            })
            console.log('this.expWrapperRes.totalExpWrapperMap = ', this.expWrapperRes.totalExpWrapperMap);
            this.finalTableData = this.finalTableData.concat(this.expWrapperRes.totalExpWrapperMap);

            var tempArr = [];
            this.netIncomeWrapperRes.forEach((ele) => {
                this.colWrapperSet && this.colWrapperSet.forEach((ele2) => {
                    ele.values && ele.values.forEach((ele3) => {
                        if (ele2 == ele3.ColumnHeader1) {
                            tempArr.push(ele3);
                        }
                    });
                });
                ele.values = tempArr;
                ele.values = [...ele.values];
                ele.isExpanded = false;
                ele.havingSubValues = false;
                var expTotal = 0;
                ele.values && ele.values.forEach((ele3) => {
                    if (ele3.amountValue < 0) {
                        ele3.CurrencyValue = '(' + (ele3.amountValue * -1) + ')';
                        ele3.styleCss = 'color:red;';
                    }
                    expTotal = expTotal + ele3.amountValue;
                });
                if (expTotal < 0) {
                    ele.values.push({
                        CurrencyValue: '(' + (expTotal * -1) + ')',
                        styleCss: 'color:red;',
                        ColumnHeader1: 'Net Income Total'
                    });
                } else {
                    ele.values.push({CurrencyValue: expTotal, ColumnHeader1: 'Expense Total'});
                }
            });

            this.finalTableData = this.finalTableData.concat(this.netIncomeWrapperRes);
            this.removeNull();
            this.removeNull();
            this.finalTableData && this.finalTableData.forEach((ele) => {
                if (ele.list && ele.list.length > 0) {
                    ele.havingSubValues = true;
                    ele.isExpanded = false;
                    ele.list && ele.list.forEach((ele2) => {
                        if (ele2.list && ele2.list.length > 0) {
                            ele2.havingSubValues = true;
                            ele2.isExpanded = false;
                            ele2.list && ele2.list.forEach((ele3) => {
                                if (ele3.list && ele3.list.length > 0) {
                                    ele3.havingSubValues = true;
                                    ele3.isExpanded = false;
                                    ele3.list && ele3.list.forEach((ele4) => {
                                        if (ele4.list && ele4.list.length > 0) {
                                            // ele4.havingSubValues = true;
                                            ele4.isExpanded = false;
                                        }
                                    });
                                }
                            });

                        }
                    });
                }
            });
            console.log('this.finalTableData = ', this.finalTableData);
        }).catch((error) => {
            console.log('Error: ', error);
        })
    }

    removeNull() {

        this.finalTableData.forEach((ele, ind) => {
            let cNullInd = [];
            let cNullList = [];
            if (ele.list) {
                ele.list.forEach((cele, cind) => {
                    if (cele.label == 'null') {
                        cNullInd.push(cind);
                        cele.list.forEach(lele => {
                            cNullList.push(lele);
                        });
                        //cNullList = cele.list;
                    }
                });
                cNullInd.forEach(iele => {
                    ele.list.splice(iele, 1);
                });
                cNullList.forEach(lele => {
                    ele.list.push(lele);
                })


            }
            cNullInd
        })

    }

    toggel(event) {
        var ind1 = event.target.dataset.ind1;
        var ind2 = event.target.dataset.ind2;
        var ind3 = event.target.dataset.ind3;
        var ind4 = event.target.dataset.ind4;
        console.log('ind1 - ', ind1);
        console.log('ind2 - ', ind2);
        console.log('ind3 - ', ind3);
        this.finalTableData && this.finalTableData.forEach((ele, index) => {
            if (index == ind1) {
                if (ind2 == undefined) {
                    ele.isExpanded = !ele.isExpanded;
                }
                else {
                    ele.isExpanded = true;
                    ele.list && ele.list.forEach((ele2, index2) => {
                        if (index2 == ind2) {
                            if (ind3 == undefined) {
                                ele.isExpanded = true;
                                ele2.isExpanded = !ele2.isExpanded;
                            }
                            else {
                                ele.isExpanded = true;
                                ele2.isExpanded = true;
                                ele2.list && ele.list.forEach((ele3, index3)=>{
                                    if(index3 == ind3){
                                        ele3.isExpanded = true;
                                    } else {
                                        ele2.isExpanded = true;
                                        ele3.isExpanded = true;
                                        ele3.list && ele2.list.forEach((ele4, index4)=>{
                                            if(index4 == ind4) {
                                                ele3.isExpanded = true;
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    })
                }
            }
        });
        this.finalTableData = [...this.finalTableData];
        console.log('this.finalTableData: ', this.finalTableData);

    }
}