declare module "@salesforce/apex/RunFinancialReports.getFinancialReportResultList" {
  export default function getFinancialReportResultList(): Promise<any>;
}
declare module "@salesforce/apex/RunFinancialReports.setFinancialReportingList" {
  export default function setFinancialReportingList(param: {FRRList: any}): Promise<any>;
}
declare module "@salesforce/apex/RunFinancialReports.getFinancialReportingList" {
  export default function getFinancialReportingList(): Promise<any>;
}
declare module "@salesforce/apex/RunFinancialReports.getFinancialReportingById" {
  export default function getFinancialReportingById(param: {fRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/RunFinancialReports.getFinancialStatementResultList" {
  export default function getFinancialStatementResultList(): Promise<any>;
}
declare module "@salesforce/apex/RunFinancialReports.deleteMultipleFinancialReportingRecord" {
  export default function deleteMultipleFinancialReportingRecord(param: {frrObj: any}): Promise<any>;
}
declare module "@salesforce/apex/RunFinancialReports.getAccountList" {
  export default function getAccountList(param: {recordId: any}): Promise<any>;
}
