declare module "@salesforce/apex/ClearedTransactions.getObjFields" {
  export default function getObjFields(param: {singleSFObjName: any}): Promise<any>;
}
declare module "@salesforce/apex/ClearedTransactions.saveRecords" {
  export default function saveRecords(param: {recsString: any, objName: any}): Promise<any>;
}
declare module "@salesforce/apex/ClearedTransactions.getSelectedObjectRecords" {
  export default function getSelectedObjectRecords(param: {sObjectType: any, allField: any}): Promise<any>;
}
declare module "@salesforce/apex/ClearedTransactions.getPicklistOptions" {
  export default function getPicklistOptions(param: {objectApiName: any, fieldApiName: any}): Promise<any>;
}
declare module "@salesforce/apex/ClearedTransactions.getRelatedObjectRecords" {
  export default function getRelatedObjectRecords(param: {objectApiName: any, fieldApiName: any}): Promise<any>;
}
