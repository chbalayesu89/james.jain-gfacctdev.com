declare module "@salesforce/apex/ReconciliationLwcController.fetchData" {
  export default function fetchData(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/ReconciliationLwcController.GFERP_GL_Entry_Button_Handler" {
  export default function GFERP_GL_Entry_Button_Handler(param: {recordId: any, GFERP_GL_Entry_Id: any, GFERP_GL_Entry_Button_Label: any}): Promise<any>;
}
declare module "@salesforce/apex/ReconciliationLwcController.clear_unclear_operation_handler" {
  export default function clear_unclear_operation_handler(param: {recordId: any, strEntryList: any, clear_unclear_operation_title: any}): Promise<any>;
}
declare module "@salesforce/apex/ReconciliationLwcController.filterActionHandler" {
  export default function filterActionHandler(param: {recordId: any, filterParams: any}): Promise<any>;
}
