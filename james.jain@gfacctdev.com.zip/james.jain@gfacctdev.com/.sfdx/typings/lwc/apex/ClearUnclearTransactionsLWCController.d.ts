declare module "@salesforce/apex/ClearUnclearTransactionsLWCController.fetchDataWrapper" {
  export default function fetchDataWrapper(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClearUnclearTransactionsLWCController.saveUnclearedBoxes" {
  export default function saveUnclearedBoxes(param: {boxIdStr: any}): Promise<any>;
}
declare module "@salesforce/apex/ClearUnclearTransactionsLWCController.saveClearedBoxes" {
  export default function saveClearedBoxes(param: {boxIdStr: any}): Promise<any>;
}
