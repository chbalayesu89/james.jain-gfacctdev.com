declare module "@salesforce/apex/FinancialReportResultController.getGlSummary" {
  export default function getGlSummary(): Promise<any>;
}
declare module "@salesforce/apex/FinancialReportResultController.getFinancialReportResultRecord" {
  export default function getFinancialReportResultRecord(param: {newItems: any}): Promise<any>;
}
declare module "@salesforce/apex/FinancialReportResultController.getFinancialStatementResultValue" {
  export default function getFinancialStatementResultValue(param: {fRRId: any}): Promise<any>;
}
