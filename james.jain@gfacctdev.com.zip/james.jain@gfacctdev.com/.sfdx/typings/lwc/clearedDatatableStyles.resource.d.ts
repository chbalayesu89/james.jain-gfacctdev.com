declare module "@salesforce/resourceUrl/clearedDatatableStyles" {
    var clearedDatatableStyles: string;
    export default clearedDatatableStyles;
}