declare module "@salesforce/resourceUrl/custommodal" {
    var custommodal: string;
    export default custommodal;
}